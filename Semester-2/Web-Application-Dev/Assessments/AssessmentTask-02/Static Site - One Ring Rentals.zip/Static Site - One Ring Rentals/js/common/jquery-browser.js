/**
 * Check if browser is a mobile device
 */
(function(){(jQuery.browser=jQuery.browser||{}).mobile=(/android|webos|iphone|ipad|ipod|blackberry/i.test(navigator.userAgent.toLowerCase()));}(navigator.userAgent||navigator.vendor||window.opera));
