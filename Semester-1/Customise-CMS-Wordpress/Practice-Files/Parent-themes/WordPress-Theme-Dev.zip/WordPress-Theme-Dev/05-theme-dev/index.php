

<?php get_header(); ?>

<h1>My Home Page - index.php</h1>

<!--<p>Add widget here </p>-->

<?php
 
//if ( is_active_sidebar( 'custom-header-widget' ) ) : ?>
    <!--<div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">-->
    <!--<?php //dynamic_sidebar( 'custom-header-widget' ); ?>
    </div>
     
<?php //endif; ?>

<!--<p>end widget</p>-->