

<?php get_header(); ?>

<h1>My Home Page - index.php</h1>