<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
get_header(); ?>
<!--Start Content /-->
<hr>
<h1> Start - page.php </h1>


<h1> End - page.php</h1>
<hr>
<!--End Content /-->
<?php get_footer(); ?>
