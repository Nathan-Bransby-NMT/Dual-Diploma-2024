<?php

// If statement

// If-Else

// Nested if statement

// If-Else-If

