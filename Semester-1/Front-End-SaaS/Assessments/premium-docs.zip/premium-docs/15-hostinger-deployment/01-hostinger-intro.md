# Section Intro

I didn't think the course would be complete without showing you how to deploy this project. 

There are many services to use for hosting. One company that I've used and have worked with for years is Hostinger. So We're going to do a full deployment to Hostinger. This includes registering a domain, SSL and getting setup as well as exporting our local database and importing into our production database.

We will also use Hostinger's extremely fast drag and drop file utility to upload our files. There will be some configuration as far as file paths and database credentials.

You can use the code TRAVERSYMEDIA to make the price even cheaper with 10% off.

