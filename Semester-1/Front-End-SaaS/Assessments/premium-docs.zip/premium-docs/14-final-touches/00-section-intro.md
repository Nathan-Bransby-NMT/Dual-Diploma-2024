# Section Intro

So we are just about there. We have a complete CRUD app with authentication and authorization. This section will be reserved for any additional features. I may add more videos to this section in the future, but for now, we'll just add a search feature.

We already have a search form on the homepage, so we'll just need to add the logic to a search method in the listings controller. We'll be using a LIKE query to search specific fields for any keywords as well as the location using the city and state of the listing.

Let's get into it.
