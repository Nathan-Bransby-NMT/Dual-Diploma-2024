{{-- Replace this with the SVG code from one of the provided logos--}}

<svg id="Layer_1" viewBox="0 0 64 64"
     {{ $attributes }}
     xmlns="http://www.w3.org/2000/svg"
     data-name="Layer 1">

</svg>
